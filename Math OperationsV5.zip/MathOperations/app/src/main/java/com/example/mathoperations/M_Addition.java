package com.example.mathoperations;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
public class M_Addition extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_m__addition);

        getSupportActionBar().setTitle(R.string.matrix_addition);
    }
}
